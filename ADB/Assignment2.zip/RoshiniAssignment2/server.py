

import os
import ibm_db
from flask import Flask,redirect,render_template,request
import urllib
import datetime
import json


app = Flask(__name__)


db2cred = {
  "db": "BLUDB",
  "dsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-sbox-yp-dal09-10.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=bqf05577;PWD=z9n5b5-g8p5r45vp;",
  "host": "dashdb-txn-sbox-yp-dal09-10.services.dal.bluemix.net",
  "hostname": "dashdb-txn-sbox-yp-dal09-10.services.dal.bluemix.net",
  "https_url": "https://dashdb-txn-sbox-yp-dal09-10.services.dal.bluemix.net",
  "jdbcurl": "jdbc:db2://dashdb-txn-sbox-yp-dal09-10.services.dal.bluemix.net:50000/BLUDB",
  "parameters": {
      "role_crn": "crn:v1:bluemix:public:iam::::serviceRole:Manager"
   },
  "password": "z9n5b5-g8p5r45vp",
  "port": 50000,
  "ssldsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-sbox-yp-dal09-10.services.dal.bluemix.net;PORT=50001;PROTOCOL=TCPIP;UID=bqf05577;PWD=z9n5b5-g8p5r45vp;Security=SSL;",
  "ssljdbcurl": "jdbc:db2://dashdb-txn-sbox-yp-dal09-10.services.dal.bluemix.net:50001/BLUDB:sslConnection=true;",
  "uri": "db2://bqf05577:z9n5b5-g8p5r45vp@dashdb-txn-sbox-yp-dal09-10.services.dal.bluemix.net:50000/BLUDB",
  "username": "bqf05577"
}
appenv = {
   "application_id": "c30bfe26-7b43-4895-86a2-c98e8535ebcf",
  "application_name": "RoshiniQuiz1App",
  "application_uris": [
   "RoshiniQuiz1App.us-south.cf.appdomain.cloud",
   "roshiniquiz1app.mybluemix.net"
  ],
  "application_version": "f768331b-dc5b-4e86-9d5a-98524b7a959d",
  "cf_api": "https://api.us-south.cf.cloud.ibm.com",
  "limits": {
   "disk": 1024,
   "fds": 16384,
   "mem": 64
  },
  "name": "RoshiniQuiz1App",
  "organization_id": "e778863d-2a1a-42d6-8f66-ff45b4267fbc",
  "organization_name": "tadiroshini12@gmail.com",
  "process_id": "c30bfe26-7b43-4895-86a2-c98e8535ebcf",
  "process_type": "web",
  "space_id": "58c1aa0e-2acd-470b-8b8b-02416f66b209",
  "space_name": "dev",
  "uris": [
   "RoshiniQuiz1App.us-south.cf.appdomain.cloud",
   "roshiniquiz1app.mybluemix.net"
  ],
  "users": '',
  "version": "f768331b-dc5b-4e86-9d5a-98524b7a959d"
 }


	
	
# handle database request and query info information
def largest():
    # connect to DB2
    db2conn = ibm_db.connect("DATABASE="+db2cred['db']+";HOSTNAME="+db2cred['hostname']+";PORT="+str(db2cred['port'])+";UID="+db2cred['username']+";PWD="+db2cred['password']+";","","")
    if db2conn:
        # we have a Db2 connection, query the database
        sql='select "mag","time","place" from EARTHQUAKES order by "mag" desc LIMIT 5'
        # Note that for security reasons we are preparing the statement first,
        # then bind the form input as value to the statement to replace the
        # parameter marker.
        stmt = ibm_db.prepare(db2conn,sql)
        ibm_db.execute(stmt)
        rows=[]
        # fetch the result
        result = ibm_db.fetch_assoc(stmt)
        while result != False:
            rows.append(result.copy())
            result = ibm_db.fetch_assoc(stmt)
        # close database connection
        ibm_db.close(db2conn)
    return render_template('large.html', r=rows)	


def magni(datefrom=None,dateto=None):
    db2conn = ibm_db.connect("DATABASE="+db2cred['db']+";HOSTNAME="+db2cred['hostname']+";PORT="+str(db2cred['port'])+";UID="+db2cred['username']+";PWD="+db2cred['password']+";","","")
    if db2conn:
        # we have a Db2 connection, query the database
        date1 = '2020-06-01'
        date2 = '2020-06-08'
        sql='select "mag","time","place" from EARTHQUAKES where "mag">3 and ("time" between ? and ?)'
        
        # Note that for security reasons we are preparing the statement first,
        # then bind the form input as value to the statement to replace the
        # parameter marker.
        stmt = ibm_db.prepare(db2conn,sql)
        ibm_db.bind_param(stmt, 1, str(datefrom))
        ibm_db.bind_param(stmt, 2, str(dateto))
        ibm_db.execute(stmt)
        rows=[]

        # fetch the result
        result = ibm_db.fetch_assoc(stmt)
        while result != False:
            rows.append(result.copy())
            result = ibm_db.fetch_assoc(stmt)
        # close database connection
        ibm_db.close(db2conn)
    return render_template('magnit.html',r=rows)	

def rad1():
    db2conn = ibm_db.connect("DATABASE="+db2cred['db']+";HOSTNAME="+db2cred['hostname']+";PORT="+str(db2cred['port'])+";UID="+db2cred['username']+";PWD="+db2cred['password']+";","","")
    if db2conn:
        # we have a Db2 connection, query the database'
        sql='SELECT * FROM EARTHQUAKES WHERE acos(sin(0.0175*32.7357) * sin(0.0175*"latitude") + cos(0.0175*32.7357) * cos(0.0175*"latitude") * cos(0.0175*"longitude" - (0.0175* -97.1081)) )* 6371 < 500'
        # Note that for security reasons we are preparing the statement first,
        # then bind the form input as value to the statement to replace the
        # parameter marker.
        stmt = ibm_db.prepare(db2conn,sql)
        ibm_db.execute(stmt)
        rows=[]
        # fetch the result
        result = ibm_db.fetch_assoc(stmt)
        while result != False:
            rows.append(result.copy())
            result = ibm_db.fetch_assoc(stmt)
        # close database connection
        ibm_db.close(db2conn)
    return render_template('rad1.html',r=rows)
    
def rad2():
    db2conn = ibm_db.connect("DATABASE="+db2cred['db']+";HOSTNAME="+db2cred['hostname']+";PORT="+str(db2cred['port'])+";UID="+db2cred['username']+";PWD="+db2cred['password']+";","","")
    if db2conn:
        # we have a Db2 connection, query the database'
        sql='SELECT * FROM EARTHQUAKES WHERE acos(sin(0.0175*32.7767) * sin(0.0175*"latitude") + cos(0.0175*32.7767) * cos(0.0175*"latitude") * cos(0.0175*"longitude" - (0.0175* -97.1081))) * 6371 < 200 order by "mag" desc LIMIT 1'
        # Note that for security reasons we are preparing the statement first,
        # then bind the form input as value to the statement to replace the
        # parameter marker.
        stmt = ibm_db.prepare(db2conn,sql)
        ibm_db.execute(stmt)
        rows=[]
        # fetch the result
        result = ibm_db.fetch_assoc(stmt)
        while result != False:
            rows.append(result.copy())
            result = ibm_db.fetch_assoc(stmt)
        # close database connection
        ibm_db.close(db2conn)
    return render_template('rad2.html',r=rows)
    
    
def ritch(magfrom=None,magto=None,datefromritch=None,datetoritch=None):
    # connect to DB2
    db2conn = ibm_db.connect("DATABASE="+db2cred['db']+";HOSTNAME="+db2cred['hostname']+";PORT="+str(db2cred['port'])+";UID="+db2cred['username']+";PWD="+db2cred['password']+";","","")
    if db2conn:
        # we have a Db2 connection, query the database
       
        sql='select count(*) from EARTHQUAKES where( "mag" BETWEEN ? AND ?) and ("time" between ? and ?)'
        #Note that for security reasons we are preparing the statement first,
        # then bind the form input as value to the statement to replace the
        # parameter marker.
        stmt = ibm_db.prepare(db2conn,sql)
        ibm_db.bind_param(stmt, 1, magfrom)
        ibm_db.bind_param(stmt, 2, magto)
        ibm_db.bind_param(stmt, 3, datefromritch)
        ibm_db.bind_param(stmt, 4, datetoritch)
        ibm_db.execute(stmt)
        rows=[]
        # fetch the result
        result = ibm_db.fetch_assoc(stmt)
        while result != False:
            rows.append(result.copy())
            result = ibm_db.fetch_assoc(stmt)
        # close database connection
        ibm_db.close(db2conn)
    return render_template('ritcher.html', r=rows)


def new():
    db2conn = ibm_db.connect("DATABASE="+db2cred['db']+";HOSTNAME="+db2cred['hostname']+";PORT="+str(db2cred['port'])+";UID="+db2cred['username']+";PWD="+db2cred['password']+";","","")
    if db2conn:
        # we have a Db2 connection, query the database
        sql='SELECT count(*) FROM EARTHQUAKES WHERE acos(sin(0.0175*32.7767) * sin(0.0175*"latitude") + cos(0.0175*32.7767) * cos(0.0175*"latitude") * cos(0.0175*"longitude" - (0.0175* (-97.1081)))) * 6371 < 1000'
        stmt = ibm_db.prepare(db2conn,sql)
        ibm_db.execute(stmt)
        rows=[]
        result = ibm_db.fetch_assoc(stmt)
        while result != False:
            rows.append(result.copy())
            result = ibm_db.fetch_assoc(stmt)
        sql1='SELECT count(*) FROM EARTHQUAKES WHERE acos(sin(0.0175*61) * sin(0.0175*"latitude") + cos(0.0175*61) * cos(0.0175*"latitude") * cos(0.0175*"longitude" - (0.0175* (-150)))) * 6371 < 1000'
        stmt = ibm_db.prepare(db2conn,sql1)
        ibm_db.execute(stmt)
        rowsa=[]
        # fetch the result
        result = ibm_db.fetch_assoc(stmt)
        while result != False:
            rowsa.append(result.copy())
            result = ibm_db.fetch_assoc(stmt)
        # close database connection
        ibm_db.close(db2conn)
    return render_template('bet.html',r=rows, f=rowsa)

@app.route('/newsearch', methods=['GET'])
def newarea():
    return new()

@app.route('/')
def index():
   return render_template('index.html', app=appenv)

@app.route('/largest5', methods=['GET'])
def large():
    return largest()

@app.route('/magnitude', methods=['GET'])
def mag():
    datefrom = request.args.get('datefrom', '')
    dateto = request.args.get('dateto', '')
    return magni(datefrom,dateto)    

@app.route('/radi1', methods=['GET'])
def radi():
    return rad1()

@app.route('/radi2', methods=['GET'])
def radii():
    return rad2()

@app.route('/ritcher', methods=['GET'])
def rit():
    rangefrom = request.args.get('magfrom', '')
    rangeto = request.args.get('magto', '')
    datefromritch = request.args.get('datefromritch', '')
    datetoritch = request.args.get('datetoritch', '')
    return ritch(rangefrom , rangeto,datefromritch,datetoritch)


 

@app.errorhandler(404)
@app.route("/error404")
def page_not_found(error):
 	return render_template('404.html',title='404')
@app.errorhandler(500)
@app.route("/error500")
def requests_error(error):
 return render_template('500.html',title='500')

port = os.getenv('PORT', '5000')
if __name__ == "__main__":
	app.run(host='0.0.0.0', port=int(port))







