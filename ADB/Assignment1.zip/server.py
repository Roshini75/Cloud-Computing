
import os
import ibm_db
from flask import Flask,redirect,render_template,request
import urllib
import datetime
import json

app = Flask(__name__)

# get service information if on IBM Cloud Platform
if 'VCAP_SERVICES' in os.environ:
    db2info = json.loads(os.environ['VCAP_SERVICES'])['dashDB For Transactions'][0]
    db2cred = db2info["credentials"]
    appenv = json.loads(os.environ['VCAP_APPLICATION'])
else:
    raise ValueError('Expected cloud environment')

def picture(Name=None):
    # connect to DB2
    db2conn = ibm_db.connect("DATABASE="+db2cred['db']+";HOSTNAME="+db2cred['hostname']+";PORT="+str(db2cred['port'])+";UID="+db2cred['username']+";PWD="+db2cred['password']+";","","")
    if db2conn:
        # we have a Db2 connection, query the database
        sql='select * from PEOPLE where "Name" = ?'
        # Note that for security reasons we are preparing the statement first,
        # then bind the form input as value to the statement to replace the
        # parameter marker.
        stmt = ibm_db.prepare(db2conn,sql)
        ibm_db.bind_param(stmt, 1, Name)
        ibm_db.execute(stmt)
        row = {}
        # fetch the result
        result = ibm_db.fetch_assoc(stmt)
        if result!=False:
            row = result.copy()
            result = ibm_db.fetch_assoc(stmt)
            print(result)
        # close database connection
        ibm_db.close(db2conn)
    return render_template('people.html', ci=row)
	
	
# handle database request and query people information
def salarysearch():
    # connect to DB2
    db2conn = ibm_db.connect("DATABASE="+db2cred['db']+";HOSTNAME="+db2cred['hostname']+";PORT="+str(db2cred['port'])+";UID="+db2cred['username']+";PWD="+db2cred['password']+";","","")
    if db2conn:
        # we have a Db2 connection, query the database
        sql='select * from PEOPLE where "salary"< 99000'
        # Note that for security reasons we are preparing the statement first,
        # then bind the form input as value to the statement to replace the
        # parameter marker.
        stmt = ibm_db.prepare(db2conn,sql)
        ibm_db.execute(stmt)
        rows=[]
        # fetch the result
        result = ibm_db.fetch_assoc(stmt)
        while result != False:
            rows.append(result.copy())
            result = ibm_db.fetch_assoc(stmt)
        # close database connection
        ibm_db.close(db2conn)
    return render_template('salary.html', ci=rows)	
	
def removePerson(name=None):
    # connect to DB2
    db2conn = ibm_db.connect("DATABASE="+db2cred['db']+";HOSTNAME="+db2cred['hostname']+";PORT="+str(db2cred['port'])+";UID="+db2cred['username']+";PWD="+db2cred['password']+";","","")
    if db2conn:
        # we have a Db2 connection, query the database
        sql='delete from people where "Name"=?'
        # Note that for security reasons we are preparing the statement first,
        # then bind the form input as value to the statement to replace the
        # parameter marker.
        stmt = ibm_db.prepare(db2conn,sql)
        ibm_db.bind_param(stmt, 1, name)
        ibm_db.execute(stmt)
        rows=[]
        # close database connection
        ibm_db.close(db2conn)
    return render_template('removedpeople.html')

# handle database request and query city information
def updatekeyword(nameToUpdate=None, keyword=None):
    # connect to DB2
    db2conn = ibm_db.connect("DATABASE="+db2cred['db']+";HOSTNAME="+db2cred['hostname']+";PORT="+str(db2cred['port'])+";UID="+db2cred['username']+";PWD="+db2cred['password']+";","","")
    if db2conn:
        # we have a Db2 connection, query the database
        sql='update PEOPLE set "keywords"=? where "Name"=?'
        # Note that for security reasons we are preparing the statement first,
        # then bind the form input as value to the statement to replace the
        # parameter marker.
        stmt = ibm_db.prepare(db2conn,sql)
        ibm_db.bind_param(stmt, 1, keyword)
        ibm_db.bind_param(stmt, 2, nameToUpdate)
        ibm_db.execute(stmt)
        rows=[]
        
        # close database connection
        ibm_db.close(db2conn)
    return render_template('updatepeople.html')	
	
def updateSalary(nameToUpdateSalary=None,salary=None):
    # connect to DB2
    db2conn = ibm_db.connect("DATABASE="+db2cred['db']+";HOSTNAME="+db2cred['hostname']+";PORT="+str(db2cred['port'])+";UID="+db2cred['username']+";PWD="+db2cred['password']+";","","")
    if db2conn:
        # we have a Db2 connection, query the database
  
        sql='update PEOPLE set "salary"=? where "Name"=?'
        # Note that for security reasons we are preparing the statement first,
        # then bind the form input as value to the statement to replace the
        # parameter marker.
        stmt = ibm_db.prepare(db2conn,sql)
        ibm_db.bind_param(stmt, 1, salary)
        ibm_db.bind_param(stmt, 2, nameToUpdateSalary)
        ibm_db.execute(stmt)
        rows=[]
        # close database connection
        ibm_db.close(db2conn)
    return render_template('updatepeople.html')	

def updatePicture(nameToUpdate=None,picture=None):
    # connect to DB2
    db2conn = ibm_db.connect("DATABASE="+db2cred['db']+";HOSTNAME="+db2cred['hostname']+";PORT="+str(db2cred['port'])+";UID="+db2cred['username']+";PWD="+db2cred['password']+";","","")
    if db2conn:
        print(picture)
        filename, file_extension = os.path.splitext(picture)
# =============================================================================
#         if ((file_extension.lower() != 'png') or (file_extension.lower() != 'png')):
#             return render_template('404.html')
# =============================================================================
            
        # we have a Db2 connection, query the database
        sql='update PEOPLE set "picture"=? where "Name"=?'
        # Note that for security reasons we are preparing the statement first,
        # then bind the form input as value to the statement to replace the
        # parameter marker.

        stmt = ibm_db.prepare(db2conn,sql)
        ibm_db.bind_param(stmt, 1, picture)
        ibm_db.bind_param(stmt, 2, nameToUpdate)
        ibm_db.execute(stmt)
        rows=[]

        # close database connection
        ibm_db.close(db2conn)
    return render_template('updatepeople.html')		

# main page to dump some environment information
@app.route('/')
def index():
   return render_template('index.html', app=appenv)

# for testing purposes - use name in URI
@app.route('/hello/<name>')
def hello(name=None):
    return render_template('hello.html', name=name)

@app.route('/search', methods=['GET'])
def searchroute():
    Name = request.args.get('name', '')
    return picture(Name)

@app.route('/searchlessthan99000', methods=['POST'])
def searchsalary():
    return salarysearch()

@app.route('/remove', methods=['GET'])
def remove():
    name = request.args.get('nameToRemove', '')
    return removePerson(name)	
	
@app.route('/updatekeyword', methods=['GET'])
def updatekey():
    nameToUpdate = request.args.get('nameToUpdateKeyword', '')
    keyword = request.args.get('newkeyword', '')
    return updatekeyword(nameToUpdate, keyword)	

@app.route('/updatesalary', methods=['GET'])
def updatesalary():
    nameToUpdateSalary = request.args.get('nameToUpdateSalary', '')
    salary = request.args.get('newSalary', '')
    return updateSalary(nameToUpdateSalary,salary)	

@app.route('/updatepicture', methods=['GET'])
def updatepicture():
    nameToUpdate = request.args.get('nameToUpdatePicture', '')
    picture = request.args.get('newPicture', '')
    if request.method == 'POST':  
        f = request.files['newPicture']  
        f.save("static/images/"+f.filename)  
    return updatePicture(nameToUpdate,picture)	
	
@app.route('/city/<name>')
def cityroute(name=None):
    return picture(name)

@app.errorhandler(404)
@app.route("/error404")
def page_not_found(error):
	return render_template('404.html',message='incorrect image format')

port = os.getenv('PORT', '5000')
if __name__ == "__main__":
	app.run(host='0.0.0.0', port=int(port))
