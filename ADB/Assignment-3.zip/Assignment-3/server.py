import os
from flask import Flask,redirect,render_template,request
import time
import random
import urllib
import datetime
import json
import redis
import pickle
import hashlib
import pymssql
app = Flask(__name__)




r = redis.Redis(host = 'roshinitadi.redis.cache.windows.net',
         port=6379, db=0, password='5HRS3dg034pEE4qhVtkgBL63WdDAG7ZJaL39U6Q6rX8=')
   
def withRestrictionsCache(datefro=None,dateto=None,num=None):
    dbconn = pymssql.connect(server='demo.cy3iz8e0e2i8.us-east-2.rds.amazonaws.com', port=1433, user='adminRoshini', password='Rosh$1996', database='Rosh')
    cursor = dbconn.cursor()
    start = time.time()
    for i in range(0,int(num)):
        success="SELECT * from EARTHQUAKES where  (time between '"+str(datefro)+"' and '"+str(dateto)+"')"
        hash = hashlib.sha256(success.encode()).hexdigest()
        key = "redis_cache:" + hash
        if (r.get(key)):
           print("redis cached")
        else:
           # Do MySQL query   
           cursor.execute(success)
           data = cursor.fetchall()
           rows = []
           for j in data:
                rows.append(str(j))  
           # Put data into cache for 1 hour
           r.set(key, pickle.dumps(list(rows)) )
           r.expire(key, 36)
        
    end = time.time()
    exectime = end - start
    return render_template('count.html', t=exectime)
	
def withRestrictions(rangfro=None,rangto=None,num=None):
    dbconn = pymssql.connect(server='demo.cy3iz8e0e2i8.us-east-2.rds.amazonaws.com', port=1433, user='adminRoshini', password='Rosh$1996', database='Rosh')
    cursor = dbconn.cursor()
    start = time.time()
    for i in range(0,int(num)):
        success="SELECT * from EARTHQUAKES where  (time between '"+str(rangfro)+"' and '"+str(rangto)+"')"
        cursor.execute(success)
    end = time.time()
    exectime = end - start
    return render_template('count.html', t=exectime)

def withoutRestrictionsCache(num=None):
    dbconn = pymssql.connect(server='demo.cy3iz8e0e2i8.us-east-2.rds.amazonaws.com', port=1433, user='adminRoshini', password='Rosh$1996', database='Rosh')
    cursor = dbconn.cursor()
    start = time.time()
    
    for i in range(0,int(num)):
        success='SELECT * FROM  EARTHQUAKES'
        hash = hashlib.sha256(success.encode()).hexdigest()
        key = "redis_cache:" + hash
        if (r.get(key)):
           print("redis cached")
        else:
           # Do MySQL query   
           cursor.execute(success)
           data = cursor.fetchall()
           rows = []
           for j in data:
               rows.append(str(j))  
           # # Put data into cache for 1 hour
           r.set(key, pickle.dumps(list(rows)) )
           r.expire(key, 36)
    end = time.time()
    exectime = end - start
    return render_template('count.html', t=exectime)
	
def withoutRestrictions(num=None):
    dbconn = pymssql.connect(server='demo.cy3iz8e0e2i8.us-east-2.rds.amazonaws.com', port=1433, user='adminRoshini', password='Rosh$1996', database='Rosh')
    cursor = dbconn.cursor()
    start = time.time()
    for i in range(0,int(num)):
        success='DELETE TOP (2) PERCENT from EARTHQUAKES;commit;'
        cursor.execute(success)
    end = time.time()
    exectime = end - start
    return render_template('count.html',t=exectime)

@app.route('/')
def hello_world():
  return render_template('index.html')

@app.route('/displaydata', methods=['GET'])
def display():
    datefro = request.args.get('datefrom')
    dateto = request.args.get('dateto')
    num = request.args.get('numr')
    return withRestrictions(datefro,dateto,num) 

@app.route('/multiplerun', methods=['GET'])
def randquery():
    datefro = request.args.get('datefrom')
    dateto = request.args.get('dateto')
    num = request.args.get('numcr')
    return withRestrictionsCache(datefro,dateto,num) 	

@app.route('/displaydatar', methods=['GET'])
def display1():
    num = request.args.get('numwr','')
    return withoutRestrictions(num) 

@app.route('/multiplerunr', methods=['GET'])
def randquery1():
    num = request.args.get('numcwr','')
    return withoutRestrictionsCache(num) 

if __name__ == '__main__':
  app.run()
