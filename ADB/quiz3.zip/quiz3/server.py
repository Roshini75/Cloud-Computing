import os
from flask import Flask,redirect,render_template,request
import pypyodbc
import time
import random
import urllib
import datetime
import json
import redis
import pickle
import hashlib

app = Flask(__name__)


dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')

r = redis.Redis(host = 'roshinitadi.redis.cache.windows.net',
        port=6379, db=0, password='5HRS3dg034pEE4qhVtkgBL63WdDAG7ZJaL39U6Q6rX8=')
   
def randrange(rangfro=None,rangto=None,num=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    start = time.time()
    for i in range(0,int(num)):
        success="SELECT * from EARTHQUAKES where  (time between '"+str(rangfro)+"' and '"+str(rangto)+"')"
        hash = hashlib.sha256(success.encode()).hexdigest()
        key = "redis_cache:" + hash
        if (r.get(key)):
           print("redis cached")
        else:
           # Do MySQL query   
           cursor.execute(success)
           data = cursor.fetchall()
           rows = []
           for j in data:
                rows.append(str(j))  
           # Put data into cache for 1 hour
           r.set(key, pickle.dumps(list(rows)) )
           r.expire(key, 36)
        cursor.execute(success)
        row =cursor.fetchall()
        print(row)
    end = time.time()
    exectime = end - start
    return render_template('place.html', t=exectime, r=row)
def x1(state=None,year=None,year1=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    success="SELECT t2.population from T1 t1 inner join T3 t2 on ( t1.column2 = '"+str(state)+"' and  t1.column1 = t2.state and t2.year between'"+str(year)+"' and '"+str(year1)+"')"
    cursor.execute(success)
    data = cursor.fetchall()
    print(data)
    # start = time.time()
    # for i in range(0,int(num)):
    #     success="SELECT * from EARTHQUAKES where  (time between "+str(rangfro)+" and "+str(rangto)+")"
    #     hash = hashlib.sha256(success.encode()).hexdigest()
    #     key = "redis_cache:" + hash
    #     if (r.get(key)):
    #        print("redis cached")
    #     else:
    #        # Do MySQL query   
    #        cursor.execute(success)
    #        data = cursor.fetchall()
    #        rows = []
    #        for j in data:
    #             rows.append(str(j))  
    #        # Put data into cache for 1 hour
    #        r.set(key, pickle.dumps(list(rows)) )
    #        r.expire(key, 36)
    #     cursor.execute(success)
    # end = time.time()
    # exectime = end - start
    return render_template('ritcher.html', ci=data)
	
def disdata(rangfro=None,rangto=None,num=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    start = time.time()
    for i in range(0,int(num)):
        success="SELECT * from EARTHQUAKES where  (time between '"+str(rangfro)+"' and '"+str(rangto)+"')"
        cursor.execute(success)
        row = cursor.fetchall()
    end = time.time()
    exectime = end - start
    return render_template('count.html', t=exectime)

def randrange1(num=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    #dbconn1 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    #c1 = dbconn1.cursor()
    success2='SELECT  count(*) from EARTHQUAKES'
    cursor.execute(success2)
    r1 = cursor.fetchall()
    start = time.time()
    
    for i in range(0,int(num)):
        success='DELETE TOP (2) PERCENT from EARTHQUAKES;commit;'
        hash = hashlib.sha256(success.encode()).hexdigest()
        key = "redis_cache:" + hash
        if (r.get(key)):
           print("redis cached")
        else:
           # Do MySQL query   
           cursor.execute(success)
           #data = cursor.fetchone()
           rows = []
           # for j in data:
           #      rows.append(str(j))  
           # # Put data into cache for 1 hour
           r.set(key, pickle.dumps(list(rows)) )
           r.expire(key, 36)
    end = time.time()
    exectime = end - start
    success1='SELECT  count(*) from EARTHQUAKES'
    cursor.execute(success1)
    r2 = cursor.fetchall()
    return render_template('count.html',r=r2,r1=r1, t=exectime)
	
def disdata1(num=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()

    success2='SELECT  count(*) from EARTHQUAKES'
    cursor.execute(success2)
    r1 = cursor.fetchall()
    start = time.time()
    for i in range(0,int(num)):
        success='DELETE TOP (2) PERCENT from EARTHQUAKES;commit;'
        cursor.execute(success)
    end = time.time()
    success1='SELECT  count(*) from EARTHQUAKES'
    cursor.execute(success1)
    r = cursor.fetchall()
    exectime = end - start
    return render_template('count.html', r1=r1,r=r,t=exectime)

def ques5():
    return render_template('value.html')

def ques7(code=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    start = time.time()
    success="SELECT Entity,Year,NumberTerroristIncidents from ti where  code = '"+str(code)+"'"
    cursor.execute(success)
    row = cursor.fetchall()
    end = time.time()
    exectime = end - start
    return render_template('place.html', t=exectime,r=row )

def ques8(yrf=None,yrt=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    start = time.time()
    success="select  count(NumberTerroristIncidents) ,year, Entity from ti where Year between '"+str(yrf)+"' and '"+str(yrf)+"' group by   Entity,year"
    cursor.execute(success)
    row = cursor.fetchall()
    end = time.time()
    exectime = end - start
    return render_template('latlon.html', t=exectime,r=row )

def ques9(spf=None,spt=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    start = time.time()
    success="select sp.Entity ,count(ti.NumberTerroristIncidents) from sp inner join  ti on sp.Prevalence between '"+str(spf)+"' and '"+str(spt)+"'  group by sp.Entity "
    cursor.execute(success)
    row = cursor.fetchall()
    end = time.time()
    exectime = end - start
    return render_template('magnit.html', t=exectime,r=row )

def ques10(yrf=None,yrt=None,spf=None,spt=None,num=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    start = time.time()
    for i in range(0,int(num)):
        success="select  count(NumberTerroristIncidents) ,year, Entity from ti where Year between '"+str(yrf)+"' and '"+str(yrf)+"' group by   Entity,year"
        cursor.execute(success)
        row = cursor.fetchall()
        success1="select sp.Entity ,count(ti.NumberTerroristIncidents) from sp inner join  ti on sp.Prevalence between '"+str(spf)+"' and '"+str(spt)+"'  group by sp.Entity "
        cursor.execute(success1)
        row1 = cursor.fetchall()
    end = time.time()
    exectime = end - start
    return render_template('ques10.html', t=exectime, r=row,r1=row1)

def disdata1(num=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    #dbconn1 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    #c1 = dbconn1.cursor()
    start = time.time()
    
    for i in range(0,int(num)):
        success='DELETE TOP (2) PERCENT from EARTHQUAKES;commit;'
        hash = hashlib.sha256(success.encode()).hexdigest()
        key = "redis_cache:" + hash
        if (r.get(key)):
           print("redis cached")
        else:
           # Do MySQL query   
           cursor.execute(success)
           #data = cursor.fetchone()
           rows = []
           # for j in data:
           #      rows.append(str(j))  
           # # Put data into cache for 1 hour
           r.set(key, pickle.dumps(list(rows)) )
           r.expire(key, 36)
    end = time.time()
    exectime = end - start
    success1='SELECT  count(*) from EARTHQUAKES'
    cursor.execute(success1)
    r2 = cursor.fetchall()
    return render_template('count.html',t=exectime)

@app.route('/')
def hello_world():
  return render_template('index.html')

@app.route('/displaydata', methods=['GET'])
def display():
    rangfro = request.args.get('datefrom')
    rangto = request.args.get('dateto')
    num = request.args.get('numr')
    return disdata(rangfro,rangto,num) 

@app.route('/multiplerun', methods=['GET'])
def randquery():
    rangfro = request.args.get('datefrom')
    rangto = request.args.get('dateto')
    num = request.args.get('numcr')
    return randrange(rangfro,rangto,num) 	

@app.route('/displaydatar', methods=['GET'])
def display1():
    num = request.args.get('numwr','')
    return disdata1(num) 

@app.route('/multiplerunr', methods=['GET'])
def randquery1():
    num = request.args.get('numcwr','')
    return randrange1(num)

@app.route('/ques5', methods=['GET'])
def ques5r():
    return ques5() 

@app.route('/ques7', methods=['GET'])
def ques7r():
    code = request.args.get('code','')
    return ques7(code) 

@app.route('/ques8', methods=['GET'])
def ques8r():
    yrf = request.args.get('yrf','')
    yrt = request.args.get('yrt','')
    return ques8(yrf,yrt) 

@app.route('/ques9', methods=['GET'])
def ques9r():
    spf = request.args.get('spf','')
    spt = request.args.get('spt','')
    return ques9(spf,spt) 
@app.route('/ques10', methods=['GET'])
def ques10r():
    yrf = request.args.get('yrfn','')
    yrt = request.args.get('yrtn','')
    spf = request.args.get('spfn','')
    spt = request.args.get('sptn','')
    num = request.args.get('num','')
    return ques10(yrf,yrt,spf,spt,num) 
@app.route('/pop', methods=['GET'])
def x():
    state = request.args.get('state','')
    year = request.args.get('year','')
    year1 = request.args.get('year1','')
    return x1(state,year,year1) 

if __name__ == '__main__':
  app.run()
