# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 19:17:33 2020

@author: tadir
"""

from flask import Flask,redirect,render_template,request,make_response
import requests
        

application = Flask(__name__)



@application.route('/')
def hello_world():
  ip = requests.get('https://checkip.amazonaws.com').text.strip()
  return render_template('index.html',ip=ip)



if __name__ == '__main__':
  application.run()
