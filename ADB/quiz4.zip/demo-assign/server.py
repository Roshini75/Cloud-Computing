import os
import math
import numpy as np
from flask import Flask,redirect,render_template,request,make_response
from io import StringIO
import pypyodbc
import time
import random
import urllib
import datetime
import json
import redis
from sklearn.cluster import KMeans
import pickle
import hashlib
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib import pyplot as plt
import base64
from io import BytesIO
from mpld3 import fig_to_html, plugins

app = Flask(__name__)


dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')

r = redis.Redis(host = 'roshinitadi.redis.cache.windows.net',
        port=6379, db=0, password='5HRS3dg034pEE4qhVtkgBL63WdDAG7ZJaL39U6Q6rX8=')
   

def piechart(mgF=None,mgt=None, num=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    ss = float((float(mgt)-float(mgF))/int(num))
    print(ss)
    sizes=[]
    labels=[]
    j = float(mgF)
    k=0
    #img=BytesIO()
    for i in range(0,int(num)):
          k= j+ss
          success="SELECT count(*) from earthquakes where mag between '"+str(j)+"'and '"+str(k)+"'"
          cursor.execute(success)
          result_set = cursor.fetchall()
          print(result_set)
          for row in result_set:
              sizes.append(row[0])
              labels.append('magrange'+str(round(j,2))+' and '+str(round(k,2)))
          j=k
    print(labels)
    print(sizes)
    colors = ['gold', 'yellowgreen', 'lightcoral','blue','red']
    explode = (0.1, 0, 0)

    plt.pie(sizes,labels=labels, autopct='%1.1f%%', shadow=True, startangle=90)
    plt.axis('equal')
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.show()
    plt.clf()
    return render_template('update.html',plot_url=plot_url)

def piechartq4(c=None,yrf=None, yrt=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    success="SELECT Smokers,Year from s where Year between '"+str(yrf)+"'and '"+str(yrt)+"' and Entity = '"+str(c)+"'"
    cursor.execute(success)
    result_set = cursor.fetchall()
    sizes=[]
    labels = []
    for row in result_set:
        sizes.append(row[0])
        labels.append(row[1])
    print(labels)
    print(sizes)
    colors = ['gold', 'yellowgreen', 'lightcoral','blue','red']
    plt.pie(sizes,labels=labels, autopct='%1.1f%%', shadow=True, startangle=90)
    plt.axis('equal')
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.show()
    plt.clf()
    return render_template('count.html',plot_url=plot_url)
def make_autopct(values):
    def my_autopct(pct):
        total = sum(values)
        val = int(round(pct*total/100.0))
        return '{p:.2f}%  ({v:d})'.format(p=pct,v=val)
    return my_autopct
  
def piechartAge():
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    sizes=[]
    c=0
    labels=[]
    success="select pclass, count(age) from titanic3 where survived='1' and sex ='female' group by pclass"
    cursor.execute(success)
    result_set = cursor.fetchall()
    #img=BytesIO()
    for row in result_set:
        sizes.append(int(row[1]))
        labels.append('pclass '+str(row[0]))
        c=c+int(row[1])
    colors = ['gold', 'yellowgreen', 'lightcoral','blue','red']
    explode = (0.1, 0, 0)
    plt.pie(sizes,labels=labels, autopct=make_autopct(sizes), shadow=True, startangle=90)
    plt.axis('equal')
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.show()
    plt.clf()
    return render_template('update.html',plot_url=plot_url)



def barchart(mgF=None,mgt=None, num=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    ss = float((float(mgt)-float(mgF))/int(num))
    print(ss)
    objects=[]
    performance=[]
    j = float(mgF)
    k=0
    #img=BytesIO()
    for i in range(0,int(num)):
          k= j+ss
          success="SELECT count(*) from earthquakes where mag between '"+str(j)+"'and '"+str(k)+"'"
          cursor.execute(success)
          result_set = cursor.fetchall()
          print(result_set)
          for row in result_set:
              performance.append(row[0])
              objects.append(str(round(j,2))+'-'+str(round(k,2)))
          j=k
    colors = ['gold', 'yellowgreen', 'lightcoral','blue','black']
    y_pos = np.arange(len(objects))
    plt.bar(y_pos, performance, color=('gold', 'yellowgreen', 'lightcoral','blue','red'),align='center', alpha=0.5)
    plt.xticks(y_pos, objects)
    plt.ylabel('Count')
    plt.title('Mag range')
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.show()
    plt.clf()
    return render_template('count.html',plot_url=plot_url)

def piechartPop(pop=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    success="select max(TotalPop/1000) from voting;"
    cursor.execute(success)
    result_set = cursor.fetchone()
    
    num = math.ceil(int(math.ceil(result_set[0]))/int(pop))
    ss = int(pop)
    sizes=[]
    labels=[]
    j =0
    k=0
    for i in range(0,int(num)):
          k= j+ss
          success="SELECT count(*) from voting where (TotalPop/1000) between '"+str(j)+"'and '"+str(k)+"'"
          cursor.execute(success)
          result_set = cursor.fetchall()
          print(result_set)
          for row in result_set:
              sizes.append(row[0])
              labels.append('pop range'+str(round(j,2))+' and '+str(round(k,2)))
          j=k
    print(labels)
    print(sizes)
    colors = ['gold', 'yellowgreen', 'lightcoral','blue','red']
    explode = (0.1, 0, 0)

    plt.pie(sizes,labels=labels, autopct='%1.1f%%', shadow=True, startangle=90)
    plt.axis('equal')
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.show()
    plt.clf()
    return render_template('update.html',plot_url=plot_url)

def barchartPercentage():
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    success="select fare, count(*) as count  from minnow_updated group  by fare;"
    cursor.execute(success)
    result_set = cursor.fetchall()
    success1="select  count(*) as count  from minnow_updated;"
    cursor.execute(success1)
    result_set1 = cursor.fetchone()
    print(result_set)
    performance=[]
    objects=[]
    for row in result_set:
        performance.append((int(row[1])/int(result_set1[0]))*100)
        objects.append(row[0])
    #img=BytesIO()
    colors = ['gold', 'yellowgreen', 'lightcoral','blue','black']
    y_pos = np.arange(len(objects))
    fig, ax = plt.subplots()    
    width = 0.75 # the width of the bars 
    ax.barh(y_pos, performance, width, color=('gold', 'yellowgreen', 'lightcoral','blue','red'))
    ax.set_yticks(y_pos+width/2)
    ax.set_yticklabels(objects, minor=False)
    #plt.bar(y_pos, performance, color=('gold', 'yellowgreen', 'lightcoral','blue','red'),align='center', alpha=0.5)
    #plt.xticks(y_pos, objects)
    plt.ylabel('Fare')
    plt.xlabel('Percentage')
    for i, v in enumerate(performance):
        ax.text(v + 3, i + .25, str(v), color='black', fontweight='bold')
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.show()
    plt.clf()
    return render_template('count.html',plot_url=plot_url)

def barchartq4(c=None,yrf=None,yrt=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    success="SELECT Smokers,Year from s where Year between '"+str(yrf)+"'and '"+str(yrt)+"' and Entity = '"+str(c)+"'"
    cursor.execute(success)
    result_set = cursor.fetchall()
    sizes=[]
    labels = []
    for row in result_set:
        sizes.append(row[0])
        labels.append(row[1])
    print(labels)
    print(sizes)
    y_pos = np.arange(len(labels))
    fig, ax = plt.subplots()    
    width = 0.75 # the width of the bars 
    ax.barh(y_pos, sizes, width, color=('green'))
    ax.set_yticks(y_pos+width/2)
    ax.set_yticklabels(labels, minor=False)
    #plt.bar(y_pos, performance, color=('gold', 'yellowgreen', 'lightcoral','blue','red'),align='center', alpha=0.5)
    #plt.xticks(y_pos, objects)
    plt.ylabel('Years')
    plt.xlabel('Smokers')
    for i, v in enumerate(sizes):
        ax.text(v + 3, i + .25, str(v), color='black', fontweight='bold')
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.show()
    plt.clf()
    return render_template('update.html',plot_url=plot_url)

def x(vfr=None,vt=None,state=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    success="SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'sp$' and  COLUMN_NAME between '"+str(vfr)+"'and '"+str(vt)+"'"
    cursor.execute(success)
    result_set = cursor.fetchall()
    
    print(result_set)
    years=[]
    c=0
    objects=[]
    for row in result_set:
        years.append(row[0])
        c = c+1
    for i in range(0,c):
         success1="select ["+years[i]+"] from sp$ where  State='"+state+"'"
         cursor.execute(success1)
         result_set1 = cursor.fetchone()
         objects.append(result_set1[0])
         
    print(years)
    print(objects)
    # X = np.array(list(zip(years, objects)))
    # kmeans = KMeans(n_clusters = int(8))
    # kmeans.fit(X)
    # centroid = kmeans.cluster_centers_
    # labels = kmeans.labels_
    # img=BytesIO()
    # all = [[]] * 8
    # for i in range(len(X)):

    #         colors = ["b.", "r.", "g.", "w.", "y.", "c.", "m.", "k."]
    #         for i in range(len(X)):
    #            plt.plot(X[i][0], X[i][1], colors[labels[i]], markersize=3)
               
    #         plt.scatter(centroid[:, 0], centroid[:, 1], marker="x", s=150, linewidths=5, zorder=10)
    #         plt.xlabel("Years :)")
    #         plt.ylabel("Population")
    #         img = BytesIO()
    #         plt.savefig(img, format='png')
    #         img.seek(0)
    #         plot_url = base64.b64encode(img.getvalue()).decode()
            
    #         plt.show()
    #         plt.clf()
    #         break      
    plt.scatter(years,objects,color="blue",alpha=0.5,marker="*")
    plt.xlabel("Years")
    plt.ylabel("Population")
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()  
    plt.show()
    plt.clf()
    return render_template('success.html',plot_url=plot_url) 



def barchartNumber(y=None):
    performance=[]
    p2=[]
    objects=[]
    for i in range(1, int(y)+1):
        k = (i*i*i)%10
        performance.append(k)
        
    for j in range(1, int(y)+1):
        k = (j*j*j)%10
        m = performance.count(k)
        
        objects.append(m)
    #img=BytesIO()
    print(performance)
    print(objects)
    p1 = list( dict.fromkeys(performance) )
    colors = ['gold', 'yellowgreen', 'lightcoral','blue','black']
    y_pos = np.arange(len(p1))
    fig, ax = plt.subplots()    
    width = 0.75 # the width of the bars 
    ax.barh(y_pos, objects, width, color=('gold', 'yellowgreen', 'lightcoral','blue','red'))
    ax.set_yticks(y_pos+width/2)
    ax.set_yticklabels(p1, minor=False)
    #plt.bar(y_pos, performance, color=('gold', 'yellowgreen', 'lightcoral','blue','red'),align='center', alpha=0.5)
    #plt.xticks(y_pos, objects)
    plt.ylabel('Number')
    plt.xlabel('Count')
    for i, v in enumerate(objects):
        ax.text(v , i + .25, str(v), color='black', fontweight='bold')
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.show()
    plt.clf()
    return render_template('count.html',plot_url=plot_url)



def totalpop(frompop=None,topop=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    start = time.time()
    success="SELECT TotalPop,Registered from voting where (TotalPop/1000) between "+str(frompop)+" and "+str(topop)+" "
    cursor.execute(success)
    rows = cursor.fetchall()
    TotalPop=[]
    Registered=[]
    for row in rows:
            TotalPop.append(float(row[0]/1000))
            Registered.append(row[1])
    X = np.array(list(zip(TotalPop, Registered)))
    kmeans = KMeans(n_clusters = int(8))
    kmeans.fit(X)
    centroid = kmeans.cluster_centers_
    labels = kmeans.labels_
    img=BytesIO()
    all = [[]] * 8
    for i in range(len(X)):

        # print(index)
        # print(X[i], labels[i])

            colors = ["b.", "r.", "g.", "w.", "y.", "c.", "m.", "k."]
            for i in range(len(X)):
               plt.plot(X[i][0], X[i][1], colors[labels[i]], markersize=3)
               
            plt.scatter(centroid[:, 0], centroid[:, 1], marker="x", s=150, linewidths=5, zorder=10)
            plt.xlabel("Total pop in millions")
            plt.ylabel("Registered")
            img = BytesIO()
            plt.savefig(img, format='png')
            img.seek(0)
            plot_url = base64.b64encode(img.getvalue()).decode()
            
            plt.show()
            plt.clf()
            break      
   
    return render_template('success.html',plot_url=plot_url) 

def scatterplotq4(c=None,yrf=None,yrt=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    success="SELECT Smokers,Year from s where Year between '"+str(yrf)+"'and '"+str(yrt)+"' and Entity = '"+str(c)+"'"
    cursor.execute(success)
    result_set = cursor.fetchall()
    sizes=[]
    labels = []
    for row in result_set:
        sizes.append(row[0])
        labels.append(row[1])
    print(labels)
    print(sizes)
    plt.scatter(labels,sizes,color="blue",alpha=0.5,marker="*")
    plt.xticks(labels)
    plt.xlabel("Years")
    plt.ylabel("Smokers")
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()  
    plt.show()
    plt.clf()
    return render_template('success.html',plot_url=plot_url) 
    

def scatter1(lat1=None,lat2=None,long1=None,long2=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    start = time.time()
    success="SELECT lat,long from minnow_updated where (lat between "+lat1+" and "+lat2+") and (long between "+long1+" and "+long2+") and survived='Y'"
    print(success)
    cursor.execute(success)
    rows = cursor.fetchall()
    print(rows)
    lat=[]
    lon=[]
    for row in rows:
            lat.append(row['lat'])
            lon.append(row['long'])
    print(lat)
    print(lon)        
    X = np.array(list(zip(lat,lon)))
    kmeans = KMeans(n_clusters = int(8))
    kmeans.fit(X)
    centroid = kmeans.cluster_centers_
    labels = kmeans.labels_
    img=BytesIO()
    all = [[]] * 8
    # for i in range(len(X)):

    #     # print(index)
    #     # print(X[i], labels[i])

    #         colors = ["b.", "r.", "g.", "w.", "y.", "c.", "m.", "k."]
    #         for i in range(len(X)):
    #            plt.plot(X[i][0],X[i][1], colors[labels[i]], markersize=1)
               
    #         plt.scatter(centroid[:, 0], centroid[:, 1], marker="x", s=150, linewidths=5, zorder=1)
    #         plt.xlabel("latitude:)")
    #         plt.ylabel("longitude")
    #         img = BytesIO()
    #         plt.savefig(img, format='png')
    #         img.seek(0)
    #         plot_url = base64.b64encode(img.getvalue()).decode()  
    #         plt.show()
    #         plt.clf()
    #         break      
    plt.plot(lat,lon)
    plt.xlabel("latitude:)")
    plt.ylabel("longitude")
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()  
    plt.show()
    plt.clf()
    
    return render_template('success.html',plot_url=plot_url)  

@app.route('/mag', methods=['GET'])
def piemag():
    mgf = request.args.get('mgf','')
    mgt = request.args.get('mgt','')
    num = request.args.get('num','')
    return piechart(mgf,mgt,num) 

@app.route('/q45', methods=['GET'])
def q45():
    c = request.args.get('cou','')
    a = request.args.get('yrf','')
    b = request.args.get('yrt','')
    return piechartq4(c,a,b) 

@app.route('/q46', methods=['GET'])
def q46():
    c = request.args.get('cou6','')
    a = request.args.get('yrf6','')
    b = request.args.get('yrt6','')
    return barchartq4(c,a,b) 

@app.route('/q47', methods=['GET'])
def q47():
    c = request.args.get('cou7','')
    a = request.args.get('yrf7','')
    b = request.args.get('yrt7','')
    return scatterplotq4(c,a,b) 

@app.route('/bar', methods=['GET'])
def bar():
    mgf = request.args.get('mgfr','')
    mgt = request.args.get('mgtr','')
    num = request.args.get('num','')
    return barchart(mgf,mgt,num) 

# @app.route('/scatter', methods=['GET'])
# def sc():
#     mgf = request.args.get('mgfs','')
#     mgt = request.args.get('mgts','')
#     return scatter(mgf,mgt)

@app.route('/scatter1', methods=['GET'])
def sc1():
    lat1 = request.args.get('lat1','')
    lat2 = request.args.get('lat2','')
    long1 = request.args.get('long1','')
    long2 = request.args.get('long2','')
    return scatter1(lat1,lat2,long1,long2)

@app.route('/pop', methods=['GET'])
def pop1():
    pfr = request.args.get('pfr','')
    pt = request.args.get('pt','')
    return totalpop(pfr,pt)

@app.route('/popr', methods=['GET'])
def popr():
    pv = request.args.get('pv','')
    return piechartPop(pv)

@app.route('/')
def hello_world():
  return render_template('index.html')

@app.route('/per', methods=['GET'])
def per():
    return barchartPercentage()
@app.route('/age', methods=['GET'])
def age():
    return piechartAge()

@app.route('/number', methods=['GET'])
def rt():
    n = request.args.get('n','')
    return barchartNumber(n)
@app.route('/x', methods=['GET'])
def c1():
    a = request.args.get('yfr','')
    b  = request.args.get('yt','')
    c = request.args.get('state','')
    return x(a,b,c)

if __name__ == '__main__':
  app.run()
