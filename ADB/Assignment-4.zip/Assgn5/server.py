import os
import numpy as np
from flask import Flask,redirect,render_template,request,make_response
from io import StringIO
import pypyodbc
import time
import random
import urllib
import datetime
import json
import redis
from sklearn.cluster import KMeans
import pickle
import hashlib
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib import pyplot as plt
import base64
from io import BytesIO
from mpld3 import fig_to_html, plugins

app = Flask(__name__)


dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')

r = redis.Redis(host = 'roshinitadi.redis.cache.windows.net',
        port=6379, db=0, password='5HRS3dg034pEE4qhVtkgBL63WdDAG7ZJaL39U6Q6rX8=')
   

def piechart(mgF=None,mgt=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    ss = float((float(mgt)-float(mgF))/5)
    print(ss)
    sizes=[]
    labels=[]
    j = float(mgF)
    k=0
    #img=BytesIO()
    for i in range(0,int(5)):
          k= j+ss
          success="SELECT count(*) from earthquakes where mag between '"+str(j)+"'and '"+str(k)+"'"
          cursor.execute(success)
          result_set = cursor.fetchall()
          print(result_set)
          for row in result_set:
              sizes.append(row[0])
              labels.append('magrange'+str(round(j,2))+' and '+str(round(k,2)))
          j=k
    print(labels)
    print(sizes)
    colors = ['gold', 'yellowgreen', 'lightcoral','blue','red']
    explode = (0.1, 0, 0)

    plt.pie(sizes,labels=labels, colors=colors,autopct='%1.1f%%', shadow=True, startangle=140)
    plt.axis('equal')
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.show()
    plt.clf()
    return render_template('update.html',plot_url=plot_url)

def barchart(mgF=None,mgt=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    ss = float((float(mgt)-float(mgF))/5)
    print(ss)
    objects=[]
    performance=[]
    j = float(mgF)
    k=0
    #img=BytesIO()
    for i in range(0,int(5)):
          k= j+ss
          success="SELECT count(*) from earthquakes where mag between '"+str(j)+"'and '"+str(k)+"'"
          cursor.execute(success)
          result_set = cursor.fetchall()
          print(result_set)
          for row in result_set:
              performance.append(row[0])
              objects.append(str(round(j,2))+'-'+str(round(k,2)))
          j=k
    colors = ['gold', 'yellowgreen', 'lightcoral','blue','black']
    y_pos = np.arange(len(objects))
    plt.bar(y_pos, performance, align='center', alpha=0.5)
    plt.xticks(y_pos, objects)
    plt.ylabel('Count')
    plt.title('Mag range')
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.show()
    plt.clf()
    return render_template('count.html',plot_url=plot_url)


def scatter(rangefrom1=None,rangeto1=None):
    dbconn = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:adbsdatabaseserver.database.windows.net,1433;Database=demo;Uid=adminRoshini;Pwd=Rosh@1996;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;')
    cursor = dbconn.cursor()
    start = time.time()
    success="SELECT depth,mag from earthquakes where mag between '"+str(rangefrom1)+"' and '"+str(rangeto1)+"' "
    cursor.execute(success)
    rows = cursor.fetchall()
    depth=[]
    mag=[]
    for row in rows:
            depth.append(row['depth'])
            mag.append(row['mag'])
    X = np.array(list(zip(depth, mag)))
    kmeans = KMeans(n_clusters = int(8))
    kmeans.fit(X)
    centroid = kmeans.cluster_centers_
    labels = kmeans.labels_
    img=BytesIO()
    all = [[]] * 8
    for i in range(len(X)):

        # print(index)
        # print(X[i], labels[i])

            colors = ["b.", "r.", "g.", "w.", "y.", "c.", "m.", "k."]
            for i in range(len(X)):
               plt.plot(X[i][0], X[i][1], colors[labels[i]], markersize=3)
               
            plt.scatter(centroid[:, 0], centroid[:, 1], marker="x", s=150, linewidths=5, zorder=10)
            img = BytesIO()
            plt.savefig(img, format='png')
            img.seek(0)
            plot_url = base64.b64encode(img.getvalue()).decode()
            plt.show()
            plt.clf()
            break      
   
    return render_template('success.html',plot_url=plot_url)  

@app.route('/mag', methods=['GET'])
def piemag():
    mgf = request.args.get('mgf','')
    mgt = request.args.get('mgt','')
    return piechart(mgf,mgt) 

@app.route('/bar', methods=['GET'])
def bar():
    mgf = request.args.get('mgfr','')
    mgt = request.args.get('mgtr','')
    return barchart(mgf,mgt) 

@app.route('/scatter', methods=['GET'])
def sc():
    mgf = request.args.get('mgfs','')
    mgt = request.args.get('mgts','')
    return scatter(mgf,mgt)

@app.route('/')
def hello_world():
  return render_template('index.html')


if __name__ == '__main__':
  app.run()
